//
//  LLNavigationController.h
//  LLNavgationBar
//
//  Created by longlz on 2017/6/19.
//  Copyright © 2017年 longlz. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
  继承LLNavigationController 为了防止返回手势卡死
 */
@interface LLNavigationController : UINavigationController

@end
