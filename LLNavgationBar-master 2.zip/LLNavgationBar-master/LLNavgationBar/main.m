//
//  main.m
//  LLNavgationBar
//
//  Created by longlz on 2017/5/12.
//  Copyright © 2017年 longlz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
